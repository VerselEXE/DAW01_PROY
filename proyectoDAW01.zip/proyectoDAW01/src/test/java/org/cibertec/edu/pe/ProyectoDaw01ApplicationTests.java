package org.cibertec.edu.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoDaw01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
